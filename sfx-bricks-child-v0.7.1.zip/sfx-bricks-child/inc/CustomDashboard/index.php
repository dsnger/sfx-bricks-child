<?php
/**
 * Security: Prevent direct access
 *
 * @package SFX_Bricks_Child_Theme
 */

defined('ABSPATH') || exit;

