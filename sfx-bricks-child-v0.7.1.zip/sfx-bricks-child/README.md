# SFX Bricks Child Theme

A WordPress child theme for Bricks Builder with enhanced features.

## Development Mode

This theme supports a development mode that disables GitHub updates during local development, preventing your development version from being overwritten by GitHub updates.

### Setup

1. Create a `.env.local` file in the theme root directory:

   ```bash
   # Set to 'true' to disable GitHub theme updates during development
   SFX_THEME_DEV_MODE=true
   ```

2. The `.env.local` file is automatically ignored by Git to ensure your local development settings are not committed.

3. When you're ready to deploy, either:
   - Delete the `.env.local` file
   - Or set `SFX_THEME_DEV_MODE=false`

### How It Works

- The environment file is loaded at theme initialization
- When `SFX_THEME_DEV_MODE=true`, the GitHub updater will not be initialized
- This prevents the theme from checking for updates during development

## Building a Release Package

To create a production-ready zip file of the theme:

1. Make sure you're in the theme root directory
2. Run the build script:

   ```bash
   ./build-theme.sh
   ```

This will:

- Extract the current version from style.css
- Create a zip file named `sfx-bricks-child-v{VERSION}.zip`
- Exclude development files (.git, node_modules, .env, etc.)
- Place the zip file in the theme root directory

## Restricting Theme Settings Access

Two-tier access control via `wp-config.php`. **If not defined, access is locked for everyone.**

```php
// Theme Settings - role OR capability (auto-detected)
define('SFX_THEME_ADMINS', 'administrator');  // or 'manage_options'

// Custom Dashboard Settings - usernames (comma-separated)
define('SFX_THEME_DASHBOARD', 'agency_user,agency_dev');
```

| SFX_THEME_ADMINS | SFX_THEME_DASHBOARD | Theme Settings | Dashboard Settings |
|------------------|---------------------|----------------|-------------------|
| Not defined | Not defined | Locked | Locked |
| Defined | Not defined | By role/cap | Locked |
| Not defined | Defined | Locked | By username |
| Defined | Defined | By role/cap | By username |

## Other Documentation
