<?php

/**
 * Silence is golden
 */