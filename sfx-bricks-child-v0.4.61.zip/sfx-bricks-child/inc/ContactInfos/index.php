<?php
// Silence is golden. 